Ekran System Client
=====

DESCRIPTION
-----------
This README.md file describes how to install the Ekran System Client on macOS systems either via software deployment or manually.


REQUIREMENTS
-----------
The Ekran System Client supports the following macOS systems:
10.14 - 12.*


INSTALLATION
-----------
To download the macOS Client installation file:
https://documentation.ekransystem.com/view/user-manual/macos-clients/installing-macos-clients/downloading-the-macos-client-installation-file

To perform Ekran System macOS Client non-interactive deployment manually:
https://documentation.ekransystem.com/view/user-manual/macos-clients/installing-macos-clients/installing-macos-clients-using-the-command-line

To update Ekran System macOS Clients:
https://documentation.ekransystem.com/view/user-manual/macos-clients/updating-macos-clients

Remote Mass Deployment of macOS Clients

To perform installation of system profiles using Jamf Pro:
https://documentation.ekransystem.com/view/user-manual/macos-clients/installing-macos-clients/remote-mass-deployment-on-macos-clients/remote-mass-deployment-on-macos-clients-using-jamf-pro

To perform installation of system profiles using Workspace ONE UEM:
https://documentation.ekransystem.com/view/user-manual/macos-clients/installing-macos-clients/remote-mass-deployment-on-macos-clients/remote-mass-deployment-on-macos-clients-using-vmware-workspace-one-uem

To uninstall macOS Clients using the command line:
https://documentation.ekransystem.com/view/user-manual/macos-clients/uninstalling-macos-clients/uninstalling-macos-clients-locally/uninstalling-macos-clients-using-the-command-line


NOTE: From Ekran System version 7.5, macOS Clients can no longer be installed by using the application.
