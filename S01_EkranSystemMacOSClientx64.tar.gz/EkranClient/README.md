Ekran System Client
=====

DESCRIPTION
-----------
The README.md file describes how to install Ekran System Client on Mac systems via software deployment or manually


REQUIREMENTS
-----------
The Ekran System Client supports follow Mac systems:
* 10.14 - 12.*


INSTALLATION
-----------
To perform Mac Ekran System Client mass deployment via a software deployment tool:
1. Unzip the **macos_agent_x64.tar.gz** and navigate to the created **EkranClient** folder.
2. Add the **EkranSystemClient-<version>.pkg** to the software deployment tool. Verify the software deployment tool settings that the  EkranSystemClient-<version>.pkg will be run after downloading.
3. Go to the **remote deploy** folder. Add **Ekran System Client.mobileconfig** and **postinstall.sh** script to the software deployment tool.
    The postinstall script should be modified with the required parameters: the name or IP address and the port of the Ekran System Server and the tenant key to use a multi-tenant mode (*SERVER*, *PORT* and *TENANT_KEY* parameters). 
    By default the Ekran System Client uses 9447 port and the default tenant key. Save changes. Verify the software deployment tool settings that the postinstall script will be setup together with the EkranSystemClient-<version>.pkg and run after the pkg installation.
4. The package is ready for deployment.


To perform Mac Ekran System Client non-interactive deployment manually:
1. Unzip **macos_agent_x64.tar.gz** and go to appeared **EkranClient** folder.
2. Run **install.sh** script with follow parameters: -h <ekran_system_server_name_or_ip> -p <port> -t <tenant_key>.  You can set multiple values of servers, separating them by ";". The parameter -p and -t are optional. By default the Ekran System Client uses 9447 port and the default tenant key.
    Important: The install.sh must be run with sudo permissions. Example:
```
sudo path_to_folder/EkranClient/install.sh -h <ekran_system_server_name_or_ip> [-p <port>] [-t <tenant_key>]
```


To perform Mac Ekran System Client interactive deployment manually:
1. Unzip the **macos_agent_x64.tar.gz** and go to appeared **EkranClient** folder.
2. Double click on the **EkranSystemClient-<version>.pkg**. During the pkg file installation the macOS requires the admin credentials. Wait for the finishing of package installation.
3. Go to the **/Applications** and double click on the **Ekran System Client.app**. Then follow the Ekran System Client.app instructions.

To perform installation of system profiles via Jamf:
1. Open the Jamf service.
2. Go to the **remote deploy/Configs for Jamf** folder. Upload the **Ekran System Client macOS 10.x.mobileconfig** if you have macOS version up to Catalina.  Upload the **Ekran System Client macOS 11.x.mobileconfig** if you have macOS version Big Sur. 

To perform installation of system profiles via Workspace ONE UEM:
1. Open your Workspace.
2. Go to the **Devices / Profiles&Sources / Profiles**. 
3. Click on the **Add / Add profile**.
4. Choose **macOS** , **Device Profile**.
5. In **General** enter the name of your profile, for example *Ekran system Client macOS 10.x*. Add your smart group.
6. Go to **Custom settings** and click **Configure**.
7. Go to the **remote deploy/Configs for Workspace ONE** folder. 
Open the **Ekran System Client macOS 10.x.xml** if you have macOS version up to Catalina. 
Open the **Ekran System Client macOS 11.x.xml** if you have macOS version Big Sur. 
Copy the text.
8. Insert into field **Custom Settings**.
9. Click on **Save and publish**.

